# Hackathon Skills Export

This bundle contains 124 hackathon-related skills exported from Leo's installed Codex/agent skills.

It was generated from `HACKATHON_SKILLS.md` in the `openai-hackathon` repo. The bundle includes the original selected skill folders, a manifest, and install scripts for another machine.

## What Is Included

- `skills/`: copied skill folders, each containing a `SKILL.md`
- `MANIFEST.tsv`: simple tab-separated manifest for humans/scripts
- `manifest.json`: structured manifest
- `install.sh`: macOS/Linux/Git Bash installer
- `install.ps1`: Windows PowerShell installer

## Install on macOS or Linux

From this folder:

```bash
chmod +x install.sh
./install.sh
```

By default, skills are copied to:

```text
~/.codex/skills/hackathon-skills
```

To install somewhere else:

```bash
CODEX_SKILLS_DIR="$HOME/.codex/skills/my-hackathon-skills" ./install.sh
```

## Install on Windows PowerShell

From this folder:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install.ps1
```

By default, skills are copied to:

```text
$HOME\.codex\skills\hackathon-skills
```

To install somewhere else:

```powershell
.\install.ps1 -TargetDir "$HOME\.codex\skills\my-hackathon-skills"
```

## Important Notes

- Some exported skills are pure instructions and should work after copying.
- Some skills describe plugin-backed or service-backed workflows, such as GitHub, Gmail, OpenAI, Composio/Rube, or Browser. Your friend may still need the relevant plugin, connector, CLI, account login, API key, or MCP server for those workflows to actually run.
- The installer does not delete existing skills. It only copies this bundle into the target folder.
- If a skill with the same folder name already exists in the target, the installer refreshes that exported folder.
