#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="${CODEX_SKILLS_DIR:-$HOME/.codex/skills/hackathon-skills}"

mkdir -p "$TARGET_DIR"

while IFS=$'\t' read -r slug name; do
  [ -n "$slug" ] || continue
  rm -rf "$TARGET_DIR/$slug"
  cp -R "$SOURCE_DIR/skills/$slug" "$TARGET_DIR/$slug"
  printf 'Installed %s (%s)\n' "$slug" "$name"
done <<'SKILL_LIST'
adapt	adapt
agentql-automation	agentql-automation
ahrefs-automation	Ahrefs Automation
animate	animate
api-and-interface-design	api-and-interface-design
apify-automation	Apify Automation
arrange	arrange
atlassian-automation	atlassian-automation
audit	audit
bolder	bolder
braintree-automation	Braintree Automation
brand-guidelines	brand-guidelines
browser-testing-with-devtools	browser-testing-with-devtools
canvas-design	canvas-design
changelog-generator	changelog-generator
ci-cd-and-automation	ci-cd-and-automation
clarify	clarify
cloudinary-automation	Cloudinary Automation
code-review-and-quality	code-review-and-quality
code-simplification	code-simplification
colorize	colorize
competitive-ads-extractor	competitive-ads-extractor
computer-use	computer-use
content-research-writer	content-research-writer
context-engineering	context-engineering
control-in-app-browser	control-in-app-browser
create-plan	create-plan
critique	critique
customer-io-automation	Customer.io Automation
datadog-logs	datadog-logs
debugging-and-error-recovery	debugging-and-error-recovery
delight	delight
deploy-pipeline	deploy-pipeline
discordbot-automation	discordbot-automation
distill	distill
documentation-and-adrs	documentation-and-adrs
documents	documents
domain-name-brainstormer	domain-name-brainstormer
elevenlabs-automation	ElevenLabs Automation
email-draft-polish	email-draft-polish
excel-automation	Excel Automation
extract	extract
firecrawl-automation	Firecrawl Automation
frontend-design	frontend-design
frontend-ui-engineering	frontend-ui-engineering
gh-address-comments	gh-address-comments
gh-fix-ci	gh-fix-ci
git-workflow-and-versioning	git-workflow-and-versioning
github	github
gmail	gmail
google-cloud-vision-automation	google-cloud-vision-automation
googlebigquery-automation	googlebigquery-automation
googlecalendar-automation	googlecalendar-automation
googlemeet-automation	googlemeet-automation
googletasks-automation	googletasks-automation
gorgias-automation	Gorgias Automation
groqcloud-automation	GroqCloud Automation
harden	harden
heygen-automation	HeyGen Automation
hunter-automation	Hunter Automation
idea-refine	idea-refine
image-enhancer	image-enhancer
imagegen	imagegen
impeccable	impeccable
incremental-implementation	incremental-implementation
instantly-automation	Instantly Automation
internal-comms	internal-comms
langsmith-fetch	langsmith-fetch
lead-research-assistant	lead-research-assistant
lemon-squeezy-automation	Lemon Squeezy Automation
linear	linear
mailerlite-automation	MailerLite Automation
mcp-builder	mcp-builder
meeting-notes-and-actions	meeting-notes-and-actions
microsoft-clarity-automation	Microsoft Clarity Automation
mistral-ai-automation	Mistral AI Automation
neon-automation	Neon Automation
netsuite-automation	NetSuite Automation
new-relic-automation	New Relic Automation
normalize	normalize
notion-knowledge-capture	notion-knowledge-capture
notion-research-documentation	notion-research-documentation
notion-spec-to-implementation	notion-spec-to-implementation
omnisend-automation	Omnisend Automation
onboard	onboard
openai-automation	OpenAI Automation
openai-docs	openai-docs
optimize	optimize
outlook-email	outlook-email
overdrive	overdrive
paperjsx	paperjsx
performance-optimization	performance-optimization
planning-and-task-breakdown	planning-and-task-breakdown
plugin-creator	plugin-creator
polish	polish
pr-review-ci-fix	pr-review-ci-fix
presentations	Presentations
quickbooks-automation	QuickBooks Automation
quieter	quieter
replicate-automation	Replicate Automation
security-and-hardening	security-and-hardening
semrush-automation	SEMrush Automation
sentry-triage	sentry-triage
shipengine-automation	shipengine-automation
shipping-and-launch	shipping-and-launch
shortcut-automation	Shortcut Automation
skill-creator	skill-creator
slack-gif-creator	slack-gif-creator
slackbot-automation	slackbot-automation
snowflake-automation	Snowflake Automation
source-driven-development	source-driven-development
spec-driven-development	spec-driven-development
spreadsheets	Spreadsheets
support-ticket-triage	support-ticket-triage
surveymonkey-automation	SurveyMonkey Automation
teach-impeccable	teach-impeccable
test-driven-development	test-driven-development
theme-factory	theme-factory
typeset	typeset
webapp-testing	webapp-testing
xero-automation	Xero Automation
yeet	yeet
zoho-books-automation	Zoho Books Automation
zoho-inventory-automation	zoho-inventory-automation
SKILL_LIST

printf '\nInstalled %s skills into %s\n' "124" "$TARGET_DIR"
printf 'Restart Codex or refresh your agent session if the skills do not appear immediately.\n'
